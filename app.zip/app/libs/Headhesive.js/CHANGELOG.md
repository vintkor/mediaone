# Headhesive changelog

## v1.2.4
- Fix resize event when using numerical offset
- Fix destroy method for resize event
- Changelog corrections

## v1.2.3
- Readme correction

## v1.2.2
- Fix UMD support

## v1.2.1
- Bump version to publish to npm

## v1.2.0
- Add UMD support
- Allow to select either the top or bottom of the offset element
- Update the offset position on browser resize
- Publish to npm
- Add license file
- Make the clone version lower z-index than original. Prevents visual overlap of both when scrolling quickly

## v1.1.1
- Fix class naming

## v1.1.0
- Call the init method internally on instance creation
- Destroy method to only destroy it's instance

## v1.0.0
- Initial
